# Bootstrap 5 Exercises

A complete set of hands-on exercises covering Bootstrap 5 from the ground up.

## 📁 Folder Structure

| Folder | Topic |
|--------|-------|
| 01-setup | Setting Up Bootstrap 5 |
| 02-structure | Bootstrap Structure and Files |
| 03-grid-basics | Fundamentals of Responsive Grid Layout |
| 04-column-layouts | Column Layouts and Grid Classes |
| 05-alignment | Alignment and Reordering in Grid |
| 06-flexbox | Responsive Flexbox Utilities |
| 07-typography | Typography |
| 08-forms | Forms |
| 09-buttons | Buttons |
| 10-navbar | Navbars and Navigation |
| 11-cards | Cards and Media Objects |
| 12-spacing | Spacing Utilities |
| 13-colors | Colors and Backgrounds |
| 14-display | Display and Visibility |
| 15-borders | Borders, Shadows, and Rounded Corners |
| 16-positioning | Positioning Utilities |
| 17-icons | Icons with Bootstrap Icons |
| 18-js-plugins | Bootstrap 5 JavaScript Plugins |
| 19-sass | Customization with Sass |

## 🚀 How to Use

Each folder contains exercise HTML files. Simply open any `.html` file in your browser — all examples use Bootstrap 5 via CDN (no installation needed for most exercises).

> **Exception:** Exercise 19 (Sass customization) requires Node.js and npm.

## 📦 CDN Links Used

- Bootstrap 5 CSS: `https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css`
- Bootstrap 5 JS Bundle: `https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js`
- Bootstrap Icons: `https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css`
